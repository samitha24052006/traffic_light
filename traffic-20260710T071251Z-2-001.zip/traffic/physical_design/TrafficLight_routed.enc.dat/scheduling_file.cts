MacroModel pin state_reg[4]/CK  21.40ps 21.40ps 21.40ps 21.40ps 0pf worst_case
MacroModel pin state_reg[4]/CK  34.80ps 34.80ps 34.80ps 34.80ps 0pf worst_case
MacroModel pin state_reg[5]/CK  40.20ps 40.20ps 40.20ps 40.20ps 0pf worst_case
MacroModel pin state_reg[4]/CK  21.40ps 21.40ps 21.40ps 21.40ps 0pf worst_case
MacroModel pin state_reg[5]/CK  40.20ps 40.20ps 40.20ps 40.20ps 0pf worst_case
