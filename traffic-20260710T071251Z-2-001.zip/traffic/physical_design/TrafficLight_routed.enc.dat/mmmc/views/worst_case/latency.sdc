set_clock_latency -0.0402  [get_pins {{state_reg[5]/CK}}]
set_clock_latency -0.0348  [get_pins {{state_reg[4]/CK}}]
