read_libs /home/install/FOUNDRY/digital/90nm/dig/lib/slow.lib
read_hdl traffic.v
elaborate
read_sdc constraints_traffic.sdc
syn_generic
syn_map
syn_opt
write_hdl > traffic_netlist.v
write_sdc  > output_constraints.sdc
gui_show
report timing > traffic_timing.rpt
report power > traffic_power.rpt
report area > traffic_cell.rpt
report gates > traffic_gates.rpt
   
